﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proiect
{
    [Serializable]
    public class MemorieRAM : Componente, ICloneable, IComparable
    {
        private string nume;
        private int size;

        public MemorieRAM() : base()
        {
            nume = "";
            size = 0;
        }

        public MemorieRAM(string p, int a, string n, int s,int cant, float pr, DateTime d) : base(p, a,cant,pr,d)
        {
            nume = n;
            size = s;
        }

        public string Nume
        {
            get { return nume; }
            set
            {
                if (value != null) nume = value;
            }
        }
       
        public int Size
        {
            get { return size; }
            set
            {
                if (value >= 0) size = value;
            }
        }

        public object Clone()
        {
            return this.MemberwiseClone();
        }

        public int CompareTo(object obj)
        {
            MemorieRAM a = (MemorieRAM)obj;
            if (this.size < a.size) return -1;
            else if (this.size > a.size) return 1;
            else return 0;
        }
        public override string ToString()
        {
            return "\n Denumire model: " + nume + "\n Capacitate(GB): " +size + base.ToString();

        }

        public static MemorieRAM operator ++(MemorieRAM m)
        {
           if(m.size<8) m.size++;
            return m;
        }

        public float CalculeazaValoareMemorie(MemorieRAM m)
        {
            return m.Cantitate * m.Pret;
        }
    }
}
