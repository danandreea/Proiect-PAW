﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proiect
{
    [Serializable]

    public class Componente
    {

            public string producator;
            public int anlansare;
            private int cantitate;
            private float pret;
            private DateTime data;


        public Componente()
            {
                producator = "";
                anlansare = 0;
                cantitate = 0;
                pret = 0;
                data = default(DateTime);
            

        }

            public Componente(string p, int a, int cant, float pr, DateTime d)
            {
                producator = p;
                anlansare = a;
                cantitate = cant;
                pret = pr;
                data = d;

            }

            public string Producator
            {
                get { return producator; }
                set
                {
                    if (value != null) producator = value;
                }
            }

            public int Anlansare
            {
                get { return anlansare; }
                set
                {
                    if (value >= 0) anlansare = value;
                }
            }


        public int Cantitate
        {
            get { return cantitate; }
            set
            {
                if (value >= 0) cantitate = value;
            }
        }

        public float Pret
        {
            get { return pret; }
            set
            {
                if (value >= 0) pret = value;
            }
        }

        public DateTime Data
        {
            get { return data; }
          
        }
        public override string ToString()
            {
                string rezultat = "\n Producator: " + producator + "\n Anul aparitiei: " + anlansare +"\n Cantitate:" + cantitate + "\n Pret: " +pret + "\n Data:" + data;
                return rezultat;
            }

            /*public float this[int index]
            {
                get
                {
                    if (pret != null && index >= 0 && index < pret.Length)
                        return pret[index];
                    else
                        return 0;
                }
                set
                {
                    if (value > 0 && index >= 0 && index < pret.Length)
                        pret[index] = value;
                }
            }*/

       /* public static Componente operator ++(Componente c)
        {
           
            for (int i = 0; i < c.pret.Length; i++)
                c.pret[i]=c.pret[i]+100;

            return c;
           
        }*/

        public static Componente operator --(Componente c)
        {
                c.anlansare --;
                return c;

        }

    
    }

}
