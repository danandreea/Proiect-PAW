﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Microsoft;
using Microsoft.Office.Interop.Excel;
using System.Reflection;
using System.Runtime.InteropServices;
using Application = Microsoft.Office.Interop.Excel._Application;

namespace proiect
{
    public partial class StocProc : Form
    {
        public List<Procesor> lista = new List<Procesor>();
        public StocProc()
        {
            InitializeComponent();
            incarcadate();
            stoc();
        }

        private void incarcadate()
        {
            StreamReader sr = new StreamReader("stocprocesoare.txt");
            string linie = null;
            while ((linie = sr.ReadLine()) != null)
            {
                try
                {

                    string producator = linie.Split('-')[0];
                    string nume = linie.Split('-')[1];
                    int an = Convert.ToInt32(linie.Split('-')[2]);
                    int socket = Convert.ToInt32(linie.Split('-')[3]);
                    int frecventa = Convert.ToInt32(linie.Split('-')[4]);
                    int nuclee = Convert.ToInt32(linie.Split('-')[5]);
                    int cant = Convert.ToInt32(linie.Split('-')[7]);
                    float pret = Convert.ToSingle(linie.Split('-')[6]);
                    DateTime data = DateTime.Parse(linie.Split('-')[8]);
                    Procesor p = new Procesor(producator, an, nume, socket, frecventa, nuclee, cant, pret, data);
                    lista.Add(p);


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            sr.Close();
            //MessageBox.Show("Date incarcate");

        }

        private void stoc()
        {
            listView1.Items.Clear();
            foreach (Procesor p in lista)
            {
                ListViewItem itm = new ListViewItem(p.producator);
                itm.SubItems.Add(p.Nume);
                itm.SubItems.Add(p.Anlansare.ToString());
                itm.SubItems.Add(p.Socket.ToString());
                itm.SubItems.Add(p.Frecventa.ToString());
                itm.SubItems.Add(p.Nuclee.ToString());
                itm.SubItems.Add(p.Pret.ToString());
                itm.SubItems.Add(p.Cantitate.ToString());
                itm.SubItems.Add(p.CalculeazaValoareProcesor(p).ToString());
                itm.SubItems.Add(p.Data.ToString());
                listView1.Items.Add(itm);

            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem itm in listView1.Items)
                if (itm.Checked)
                {
                    if (MessageBox.Show("Esti sigur ca vrei sa stergi?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        itm.Remove();
                    }
                }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            GraficProcesoare frm8 = new GraficProcesoare();
            frm8.ShowDialog();
            this.Close();
        }

        private void stergeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem itm in listView1.Items)
                if (itm.Selected) itm.Remove();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Meniu frm7 = new Meniu();
            frm7.ShowDialog();
            this.Close();
        }

        private void exportEXCELToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Microsoft.Office.Interop.Excel.Application xla = new Microsoft.Office.Interop.Excel.Application();
            xla.Visible = true;
            Workbook wb = xla.Workbooks.Add(XlSheetType.xlWorksheet);
            Worksheet ws = (Worksheet)xla.ActiveSheet;
            int j = 1, i = 1;
            foreach (ListViewItem itm in listView1.Items)
            {
                ws.Cells[i, j] = itm.Text.ToString();
                foreach (ListViewItem.ListViewSubItem drv in itm.SubItems)
                {
                    ws.Cells[i, j] = drv.Text.ToString();
                    j++;
                }
                j = 1;
                i++;
            }
        }

        private void salvareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
               
                StreamWriter sw = new StreamWriter("stocprocesoare.txt");

                foreach (ListViewItem itm in listView1.Items)
                {
                    for (int i = 0; i < itm.SubItems.Count; i++)
                    {
                        if (i != itm.SubItems.Count - 2)
                            sw.Write(itm.SubItems[i].Text);
                        if (i != itm.SubItems.Count - 2 && i != itm.SubItems.Count - 1)
                        {
                            sw.Write("-");
                        }
                    }
                    sw.WriteLine();
                }
                sw.Close();
                MessageBox.Show("Datele au fost salvate!");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            WindowState = WindowState == FormWindowState.Maximized
                    ? FormWindowState.Normal
                    : FormWindowState.Maximized;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
