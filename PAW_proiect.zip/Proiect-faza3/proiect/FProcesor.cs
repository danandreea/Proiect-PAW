﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proiect
{
    public partial class FProcesor : Form
    {
       
        public List<Componente> lista = new List<Componente>();
        public FProcesor()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
             if (tbNume.Text == "")
                errorProvider1.SetError(tbNume, "Introduceti modelul!");
            else
            if (tbproducator.Text == "")
                errorProvider1.SetError(tbproducator, "Introduceti numele producatorului!");
            else
            if (tbAn.Text == "")
                errorProvider1.SetError(tbAn, "Introduceti anul!");
          else
            if (tbSocket.Text == "")
                errorProvider1.SetError(tbSocket, "Introduceti socket!");
            else
            if (tbFrecventa.Text == "")
                errorProvider1.SetError(tbFrecventa, "Introduceti frecventa!");
            else
            if (tbNuclee.Text == "")
                errorProvider1.SetError(tbNuclee, "Introduceti numarul de nuclee!");
            else
            if (tbCantitate.Text == "")
                errorProvider1.SetError(tbCantitate, "Introduceti cantitatea!");
            else
            if (tbPret.Text == "")
                errorProvider1.SetError(tbPret, "Introduceti pretul!");
            else
            {
                try
                {

                    string producator = tbproducator.Text;
                    int an = Convert.ToInt32(tbAn.Text);
                    string nume = tbNume.Text;
                    int socket = Convert.ToInt32(tbSocket.Text);
                    int frecventa = Convert.ToInt32(tbFrecventa.Text);
                    int nuclee = Convert.ToInt32(tbNuclee.Text);
                    int cant = Convert.ToInt32(tbCantitate.Text);
                    float pret = Convert.ToSingle(tbPret.Text);
                    DateTime data= this.dateTimePicker1.Value.Date;
                    Procesor p = new Procesor(producator, an, nume, socket, frecventa, nuclee,cant, pret, data);
                    lista.Add(p);
                    MessageBox.Show("Componenta a fost adaugata cu succes!\n" + p.ToString());
                    string filename = "stocprocesoare.txt";
                    File.AppendAllText(filename, "\r\n" + p.Producator + "-" + p.Nume + "-" + p.Anlansare + "-" + p.Socket+
                        "-"+p.Frecventa + "-" + p.Nuclee + "-" + p.Pret + "-" + p.Cantitate + "-" + p.Data);
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                finally
                {
                  
                    tbproducator.Clear();
                    tbAn.Clear();
                    tbNume.Clear();
                    tbSocket.Clear();
                    tbFrecventa.Clear();
                    tbNuclee.Clear();
                    tbCantitate.Clear();
                    tbPret.Clear();
                    dateTimePicker1.Value = DateTime.Now;

                }
            }
        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;

        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control == true && e.KeyCode == Keys.A)
            {
                button1.PerformClick();
            }

        }

        private void tbproducator_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back))
                e.Handled = true;
        }

        private void tbAn_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == (char)8)
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void tbSocket_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == (char)8)
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void tbFrecventa_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == (char)8)
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void tbNuclee_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == (char)8)
                e.Handled = false;
            else
                e.Handled = true;
        }
    

        Thread th;
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(opennewform);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }
        private void opennewform(object obj)
        {
            Application.Run(new Meniu());
        }

     
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            button1.FlatAppearance.BorderSize = 0;
            WindowState = WindowState == FormWindowState.Maximized
                        ? FormWindowState.Normal
                        : FormWindowState.Maximized;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private bool dragging = false;
        private Point startPoint = new Point(0, 0);
        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            startPoint = new Point(e.X, e.Y);
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this.startPoint.X, p.Y - this.startPoint.Y);
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            StocCalculatoare frm = new StocCalculatoare();
            frm.ShowDialog();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            StocProc frm = new StocProc();
            frm.ShowDialog();
            this.Close();
        }
    } 
}
