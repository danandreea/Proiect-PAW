﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proiect
{
    public partial class GraficProcesoare : Form
    {
        double[] vect = new double[20];
        string[] nume = new string[20];
        int nrElem = 0;
        bool vb = false;

        const int marg = 10;

        Color culoare = Color.DeepPink;
        Color culoare2 = Color.Blue;
        Font font = new Font(FontFamily.GenericSansSerif, 12, FontStyle.Bold);
        Font font2 = new Font(FontFamily.GenericSansSerif, 9, FontStyle.Bold);
        public GraficProcesoare()
        {
            InitializeComponent();
            grafic();
        }

        private void grafic()
        {
            StreamReader sr = new StreamReader("stocprocesoare.txt");

            string linie = null;
            while ((linie = sr.ReadLine()) != null)
            {
                try
                {
                    vect[nrElem] =(float)(Convert.ToSingle(linie.Split('-')[6]) * Convert.ToInt32(linie.Split('-')[7]));
                    nume[nrElem] =linie.Split('-')[1];
                    nrElem++;
                    vb = true;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            sr.Close();
            MessageBox.Show("Graficul a fost efectuat!");
            panel1.Invalidate();

        }
        
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            if (vb == true)
            {
                Graphics g = e.Graphics;
                Rectangle rec = new Rectangle(panel1.ClientRectangle.X + marg, panel1.ClientRectangle.Y + 2 * marg,
                    panel1.ClientRectangle.Width - 2 * marg, panel1.ClientRectangle.Height - 4 * marg);
                Pen pen = new Pen(Color.Blue, 3);
                g.DrawRectangle(pen, rec);

                double latime = rec.Width / nrElem / 3;
                double distanta = (rec.Width - nrElem * latime) / (nrElem + 1);
                double vMax = vect.Max();

                Brush br = new SolidBrush(culoare);
                Brush br2 = new SolidBrush(culoare2);

                Rectangle[] recs = new Rectangle[nrElem];
                for (int i = 0; i < nrElem; i++)
                {
                    recs[i] = new Rectangle((int)(rec.Location.X + (i + 1) * distanta + i * latime),
                      (int)(rec.Location.Y + rec.Height - vect[i] / vMax * rec.Height),
                      (int)latime,
                      (int)(vect[i] / vMax * rec.Height));
                    g.DrawString(vect[i].ToString() + " lei", font2, br2, new Point((int)(recs[i].Location.X + latime / 200),
                        (int)(recs[i].Location.Y - font.Height)));

                    g.DrawString(nume[i].ToString(), font2, br2, new Point((int)(recs[i].Location.X + latime / 200),
                      (int)(recs[i].Location.Y + recs[i].Height)));
                }
                g.FillRectangles(br, recs);
            }
        }

        private void save(Control c, string denumire)
        {
            Bitmap img = new Bitmap(c.Width, c.Height);
            c.DrawToBitmap(img, new Rectangle(c.ClientRectangle.X, c.ClientRectangle.Y,
                c.ClientRectangle.Width, c.ClientRectangle.Height));
            img.Save(denumire);
            img.Dispose();
        }
        private void salvareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            save(panel1, "preturiprocesoare.bmp");
            MessageBox.Show("Graficul a fost salvat!");
        }

        private void pdPrint(object sender, PrintPageEventArgs e)
        {
            if (vb == true)
            {
                Graphics g = e.Graphics;
                Rectangle rec = new Rectangle(panel1.ClientRectangle.X + marg, panel1.ClientRectangle.Y + 2 * marg,
                   panel1.ClientRectangle.Width - 2 * marg, panel1.ClientRectangle.Height - 4 * marg);
                Pen pen = new Pen(Color.Blue, 3);
                g.DrawRectangle(pen, rec);

                double latime = rec.Width / nrElem / 3;
                double distanta = (rec.Width - nrElem * latime) / (nrElem + 1);
                double vMax = vect.Max();

                Brush br = new SolidBrush(culoare);
                Brush br2 = new SolidBrush(culoare2);

                Rectangle[] recs = new Rectangle[nrElem];
                for (int i = 0; i < nrElem; i++)
                {
                    recs[i] = new Rectangle((int)(rec.Location.X + (i + 1) * distanta + i * latime),
                      (int)(rec.Location.Y + rec.Height - vect[i] / vMax * rec.Height),
                      (int)latime,
                      (int)(vect[i] / vMax * rec.Height));
                    g.DrawString(vect[i].ToString() + " lei", font2, br, new Point((int)(recs[i].Location.X + latime / 200),
                        (int)(recs[i].Location.Y - font.Height)));
                    g.DrawString(nume[i].ToString(), font2, br2, new Point((int)(recs[i].Location.X + latime / 200),
                     (int)(recs[i].Location.Y + recs[i].Height)));
                }
                g.FillRectangles(br, recs);
            }
        }

        private void printPreviewToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += new PrintPageEventHandler(pdPrint);
            PrintPreviewDialog dlg = new PrintPreviewDialog();
            dlg.Document = pd;
            dlg.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            StocProc frm1 = new StocProc();
            frm1.ShowDialog();
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {

            WindowState = WindowState == FormWindowState.Maximized
                        ? FormWindowState.Normal
                        : FormWindowState.Maximized;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
