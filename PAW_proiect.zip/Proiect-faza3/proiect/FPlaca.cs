﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proiect
{
    public partial class FPlaca : Form
    {
        List<Componente> lista = new List<Componente>();
        public FPlaca()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
             if (tbNume.Text == "")
                errorProvider1.SetError(tbNume, "Introduceti modelul!");
             else
            if (tbProducator.Text == "")
                errorProvider1.SetError(tbProducator, "Introduceti numele producatorului!");
            else
             if (tbAn.Text == "")
                errorProvider1.SetError(tbAn, "Introduceti anul!");
            else
             if (tbSerie.Text == "")
                errorProvider1.SetError(tbSerie, "Introduceti seria!");
            else
             if (tbFrecventa.Text == "")
                errorProvider1.SetError(tbFrecventa, "Introduceti frecventa!");
            else
            if (tbCantitate.Text == "")
                errorProvider1.SetError(tbCantitate, "Introduceti cantitatea!");
            else
            if (tbPret.Text == "")
                errorProvider1.SetError(tbPret, "Introduceti pretul!");
            else
            {
                try
                {

                    string producator = tbProducator.Text;
                    int an = Convert.ToInt32(tbAn.Text);
                    string nume = tbNume.Text;
                    string serie = tbSerie.Text;
                    int frecventa = Convert.ToInt32(tbFrecventa.Text);
                    int cant = Convert.ToInt32(tbCantitate.Text);
                    float pret = Convert.ToSingle(tbPret.Text);
                    DateTime data = this.dateTimePicker1.Value.Date;
                    Placavideo p = new Placavideo(producator, an, nume, serie, frecventa,cant,pret,data);
                    lista.Add(p);
                    MessageBox.Show("Componenta a fost adaugata cu succes!\n" +p.ToString());
                    string filename = "stocplacivideo.txt";
                    File.AppendAllText(filename, "\r\n" + p.Producator + "-"+p.Nume + "-" + p.Anlansare + "-" +p.Serie+"-"+p.Frecventa + "-" + p.Pret+"-" + p.Cantitate+"-" +p.Data);
                    
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {

                    tbProducator.Clear();
                    tbAn.Clear();
                    tbNume.Clear();
                    tbSerie.Clear();
                    tbFrecventa.Clear();
                    tbCantitate.Clear();
                    tbPret.Clear();
                    dateTimePicker1.Value = DateTime.Now;

                }
            }

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;

        }
        private void Form5_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control == true && e.KeyCode == Keys.A)
            {
                button1.PerformClick();
            }

        }

        private void tbProducator_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!(char.IsLetter(e.KeyChar) || e.KeyChar == (char)Keys.Back))
                e.Handled = true;
        }

        private void tbAn_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == (char)8)
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void tbFrecventa_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == (char)8)
                e.Handled = false;
            else
                e.Handled = true;
        }

       

        Thread th;
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(opennewform);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }
        private void opennewform(object obj)
        {
            Application.Run(new Meniu());
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {

            button1.FlatAppearance.BorderSize = 0;
            WindowState = WindowState == FormWindowState.Maximized
                        ? FormWindowState.Normal
                        : FormWindowState.Maximized;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private bool dragging = false;
        private Point startPoint = new Point(0, 0);
        private void Form5_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            startPoint = new Point(e.X, e.Y);
        }

        private void Form5_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void Form5_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - this.startPoint.X, p.Y - this.startPoint.Y);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            StocPlaci frm1 = new StocPlaci();
            frm1.ShowDialog();
            this.Close();
        }
    }
}