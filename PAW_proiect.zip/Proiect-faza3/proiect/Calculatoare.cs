﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proiect
{
   public class Calculatoare : IValoare
    {
        private string tip;
        private string model;
        private int[] dimensiuni;
        private string[] porturi;
        private int cantitate;
        private float pret;
        private DateTime data;
        

        public Calculatoare()
        {
            tip = "";
            model = "";
            dimensiuni = null;
            porturi = null;
            cantitate = 0;
            pret = 0;
            data = default(DateTime);
           
        }

        public Calculatoare(string tipc, string modelc, int[] dimensiunic, string[] porturic, int cantitatec, float pretc, DateTime d)
        {
            tip = tipc;
            model = modelc;
            dimensiuni = new int[dimensiunic.Length];
            for (int i = 0; i < dimensiunic.Length; i++)
                dimensiuni[i] = dimensiunic[i];
            porturi = new string[porturic.Length];
            for (int i = 0; i < porturic.Length; i++)
                porturi[i] = porturic[i];
            cantitate = cantitatec;
            pret = pretc;
            data = d;
        }

        public Calculatoare(string tipc, string modelc, int cantitatec, float pretc, DateTime d)
        {
            tip = tipc;
            model = modelc;
            cantitate = cantitatec;
            pret = pretc;
            data = d;
        }
        public string Tip
        {
            get { return tip; }
            set
            {
                if (value != null) model = tip;
            }
        }
        public string Model
        {
            get { return model; }
            set
            {
                if (value != null) model = value;
            }
        }

        public int[] Dimensiuni
        {
            get { return dimensiuni; }
            set
            {
                dimensiuni= new int[value.Length];
                for (int i = 0; i < value.Length; i++)
                    dimensiuni[i] = value[i];
            }
        }
        public string[] Porturi
        {
            get { return porturi; }
            set
            {
                porturi = new string[value.Length];
                for (int i = 0; i < value.Length; i++)
                    porturi[i] = value[i];
            }
        }

        public int Cantitate
        {
            get { return cantitate; }
            set
            {
                if (value>=0) cantitate = value;
            }
        }
        public float Pret
        {
            get { return pret; }
            set
            {
                if (value>=0) pret = value;
            }
        }

        public DateTime Data
        {
            get { return data; }

        }

        public string afisare()
        { 
            string rezultat = "";
            rezultat += "Tip calculator: " + tip + Environment.NewLine+ "Calculatorul " + model + " are urmatoarele caracteristici si componente: " + Environment.NewLine;
            if (dimensiuni != null)
            {
                rezultat += "Dimensiuni: ";
                for (int i = 0; i < dimensiuni.Length; i++)
                    rezultat += dimensiuni[i] + ", ";
            }
            else rezultat += "Nu exista dimensiuni disponibile.";
            rezultat += Environment.NewLine;
            if (porturi != null)
            {
                rezultat += "Porturi: ";
                for (int i = 0; i < porturi.Length; i++)
                    rezultat += porturi[i] + ", ";
            }
            else rezultat += "Nu are porturi.";
            rezultat += Environment.NewLine;
            rezultat += "Cantitate: " + cantitate + Environment.NewLine + "Pret: " + pret+ Environment.NewLine;
            return rezultat;
        }

        public int this[int index]
        {
            get
            {
                if (dimensiuni != null && index >= 0 && index < dimensiuni.Length)
                    return dimensiuni[index];
                else
                    return 0;
            }
            set
            {
                if (value > 0 && index >= 0 && index < dimensiuni.Length)
                    dimensiuni[index] = value;
            }
        }

        public float CalculeazaValoareaTotala(Calculatoare c)
        {
            return c.cantitate * c.pret;
        }
    }

}