﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proiect
{
    [Serializable]
    public class Placavideo: Componente, ICloneable, IComparable
    {
        private string nume;
        private string serie;
        private int frecventa;

        public Placavideo() : base()
        {
            nume = "";
            serie = "";
            frecventa = 0;
        }

        public Placavideo(string p, int a, string n, string s, int f,int c, float pr,DateTime d) : base(p, a,c,pr,d)
        {
            nume = n;
            serie = s;
            frecventa = f;
            
        }
        public string Nume
        {
            get { return nume; }
            set
            {
                if (value != null) nume = value;
            }
        }
        public string Serie
        {
            get { return serie; }
            set
            {
                if (value != null) serie= value;
            }
        }

        public int Frecventa
        {
            get { return frecventa; }
            set
            {
                if (value >= 0) frecventa = value;
            }
        }


        public override string ToString()
        {
            return "\n Denumire model: " + nume + "\n Serie: "+serie+ "\n Frecventa(Mhz): " + frecventa + base.ToString();

        }

        public object Clone()
        {
            return this.MemberwiseClone();
        }

        public int CompareTo(object obj)
        {
            Placavideo a = (Placavideo)obj;
            if (this.frecventa < a.frecventa) return -1;
            else if (this.frecventa > a.frecventa) return 1;
            else return 0;
        }
        public static Placavideo operator ++(Placavideo p)
        {
            p.frecventa+=100;
            return p;
        }

        public static explicit operator float(Placavideo v)
        {
            return (float)v.frecventa;
        }

              public float CalculeazaValoarePlaci(Placavideo pv)
        {
            return pv.Cantitate * pv.Pret;
        }
    }
}
