﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proiect
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OleDbConnection conexiune = new OleDbConnection("Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Producatori.accdb");

            try
            {
                conexiune.Open();
                OleDbCommand comanda = new OleDbCommand();
                comanda.Connection = conexiune;
                comanda.CommandText = "SELECT MAX(ID) FROM Producatori";
                int cod = Convert.ToInt32(comanda.ExecuteScalar());
                comanda.CommandText = "INSERT INTO Producatori VALUES(?,?,?,?,?,?)";
                comanda.Parameters.Add("ID", OleDbType.Integer).Value = cod + 1;
                comanda.Parameters.Add("Nume", OleDbType.Char, 30).Value = tbNume.Text;
                comanda.Parameters.Add("Adresa", OleDbType.Char, 255).Value = tbAdresa.Text;
                comanda.Parameters.Add("Telefon", OleDbType.Char, 15).Value = tbTelefon.Text;
                comanda.Parameters.Add("E-mail", OleDbType.Char, 30).Value = tbEmail.Text;
                comanda.Parameters.Add("Produs", OleDbType.Char, 20).Value = cbTip.Text;
                comanda.ExecuteNonQuery();
                MessageBox.Show("Producatorul a fost adaugat cu succes!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexiune.Close();
                tbNume.Clear();
                tbAdresa.Clear();
                tbTelefon.Clear();
                tbEmail.Clear();
                cbTip.Text = "";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            WindowState = WindowState == FormWindowState.Maximized
                       ? FormWindowState.Normal
                       : FormWindowState.Maximized;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
