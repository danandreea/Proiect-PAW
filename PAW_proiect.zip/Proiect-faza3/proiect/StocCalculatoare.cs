﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Drawing.Printing;
using Microsoft;
using Microsoft.Office.Interop.Excel;
using System.Reflection;
using System.Runtime.InteropServices;
using Application = Microsoft.Office.Interop.Excel._Application;

namespace proiect
{
    public partial class StocCalculatoare : Form
    {
        List<Calculatoare> listaCalc = new List<Calculatoare>();
        public StocCalculatoare()
        {
            InitializeComponent();   
            incarcadate();
            stoc();
        }


        private void stoc()
        {
            listView1.Items.Clear();
            foreach (Calculatoare c in listaCalc)
            {
                IValoare i1 = new Calculatoare();
                ListViewItem itm = new ListViewItem(c.Tip);
                itm.SubItems.Add(c.Model);
                itm.SubItems.Add(c.Cantitate.ToString());
                itm.SubItems.Add(c.Pret.ToString());
                itm.SubItems.Add(i1.CalculeazaValoareaTotala(c).ToString());
                itm.SubItems.Add(c.Data.ToString());
                listView1.Items.Add(itm);

            }
        }
      
        public void incarcadate()
        {
            StreamReader sr = new StreamReader("stoccalculatoare.txt");
            string linie = null;
            while ((linie = sr.ReadLine()) != null)
            {
                try
                {
                    string tip = linie.Split('-')[0];
                    string model = linie.Split('-')[1];
                    int cantitate = Convert.ToInt32(linie.Split('-')[2]);
                    float pret = Convert.ToSingle(linie.Split('-')[3]);
                    DateTime data = DateTime.Parse(linie.Split('-')[4]);
                    Calculatoare c = new Calculatoare(tip, model, cantitate, pret,data);
                    listaCalc.Add(c);

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            sr.Close();
           // MessageBox.Show("Date incarcate");
        }

        private void stergeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem itm in listView1.Items)
                if (itm.Selected) itm.Remove();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TreeNode parinte = new TreeNode("Calculatoare");
            treeView1.Nodes.Add(parinte);

            foreach (Calculatoare c in listaCalc)
            {
                TreeNode copil = new TreeNode(c.Tip + "-" + c.Model);
                parinte.Nodes.Add(copil);

                TreeNode nepot = new TreeNode(c.Cantitate + " buc - " + c.Pret + " lei");
                copil.Nodes.Add(nepot);
            }
            treeView1.ExpandAll();
        }


        private void stergeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            TreeNode nodSelectat = treeView1.SelectedNode;
            if (nodSelectat.NextNode != null) nodSelectat = treeView1.SelectedNode.NextNode;
            else if (nodSelectat.PrevNode != null) nodSelectat = treeView1.SelectedNode.PrevNode;
            treeView1.SelectedNode.Remove();
            treeView1.SelectedNode = nodSelectat;
        }

        private void exportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MemoryStream memStream = new MemoryStream();
            XmlTextWriter writer = new XmlTextWriter(memStream, Encoding.UTF8);
            writer.Formatting = Formatting.Indented;

            writer.WriteStartDocument();
            foreach (TreeNode parinte in treeView1.Nodes)
            {
                writer.WriteStartElement(parinte.Text);
                foreach (TreeNode copil in parinte.Nodes)
                {
                    writer.WriteStartElement(copil.Text);
                    foreach (TreeNode nepot in copil.Nodes)
                    {
                        writer.WriteStartElement(nepot.Text);
                        writer.WriteEndElement();

                    }
                    writer.WriteEndElement();

                }
                writer.WriteEndElement();

            }
            writer.WriteEndDocument();
            writer.Close();
            string str = Encoding.UTF8.GetString(memStream.ToArray());
            memStream.Close();

            StreamWriter sw = new StreamWriter("fisier.xml");
            sw.WriteLine(str);
            sw.Close();

            MessageBox.Show("Exportat");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            foreach (ListViewItem itm in listView1.Items)
                if (itm.Checked)
                {
                    if (MessageBox.Show("Esti sigur ca vrei sa stergi?", "Confirm Delete", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        itm.Remove();
                    }
                }
        }


        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Meniu frm7 = new Meniu();
            frm7.ShowDialog();
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            WindowState = WindowState == FormWindowState.Maximized
                      ? FormWindowState.Normal
                      : FormWindowState.Maximized;
        }

      
        private void salvareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
               
                StreamWriter sw = new StreamWriter("stoccalculatoare.txt");

                foreach (ListViewItem itm in listView1.Items)
                {
                    for (int i = 0; i < itm.SubItems.Count; i++)
                    {
                        if(i!=itm.SubItems.Count-2)
                            sw.Write(itm.SubItems[i].Text);
                        if (i != itm.SubItems.Count - 2 && i!=itm.SubItems.Count-1)
                        {
                            sw.Write("-");
                        }
                    }
                    sw.WriteLine();
                }
                sw.Close();
                MessageBox.Show("Datele au fost salvate!");

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
      
        private void exportEXCELToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application xla = new Microsoft.Office.Interop.Excel.Application();
            xla.Visible = true;
            Workbook wb = xla.Workbooks.Add(XlSheetType.xlWorksheet);
            Worksheet ws = (Worksheet)xla.ActiveSheet;
            int j = 1, i = 1;
            foreach (ListViewItem itm in listView1.Items)
            {
                ws.Cells[i, j] = itm.Text.ToString();
                foreach (ListViewItem.ListViewSubItem drv in itm.SubItems)
                {
                    ws.Cells[i, j] = drv.Text.ToString();
                    j++;
                }
                j = 1;
                i++;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            GraficCalc frm1 = new GraficCalc();
            frm1.ShowDialog();
            this.Close();
        }

        private void listView1_ItemDrag(object sender, ItemDragEventArgs e)
        {
            listView1.DoDragDrop(listView1.SelectedItems, DragDropEffects.Move);
        }

        private void listView1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Move;
        }

        private void listView1_DragDrop(object sender, DragEventArgs e)
        {
            if (listView1.SelectedItems.Count == 0) { return; }
            System.Drawing.Point pt = listView1.PointToClient(new System.Drawing.Point(e.X, e.Y));
            ListViewItem ItemDrag = listView1.GetItemAt(pt.X, pt.Y);
            if(ItemDrag==null) { return; }
            int ItemDragIndex = ItemDrag.Index;
            ListViewItem[] Sel = new ListViewItem[listView1.SelectedItems.Count];
            for(int i=0; i< listView1.SelectedItems.Count;i++)
            {
                Sel[i] = listView1.SelectedItems[i];
            }
            for(int i=0; i<Sel.GetLength(0);i++)
            {
                ListViewItem Item = Sel[i];
                int ItemIndex = ItemDragIndex;
                if (ItemIndex == Item.Index)
                {
                    return;
                }
                if(Item.Index<ItemIndex) { ItemIndex++; }
                else { ItemIndex = ItemDragIndex + 1; }

                ListViewItem InsertItem = (ListViewItem)Item.Clone();
                listView1.Items.Insert(ItemIndex, InsertItem);
                listView1.Items.Remove(Item);
            }

        }


    }
    }
