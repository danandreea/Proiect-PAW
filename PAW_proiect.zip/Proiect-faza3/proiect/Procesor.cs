﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace proiect
{
    [Serializable]
    public class Procesor : Componente, ICloneable, IComparable
    {
        private string nume;
        private int socket;
        private int frecventa;
        private int nuclee;
      

        public Procesor()
              : base()
        {
            nume = "";
            socket = 0;
            frecventa = 0;
            nuclee = 0;
            
        }

        public Procesor(string p, int a, string n, int s, int f, int nu, int c, float pr, DateTime d) : base(p, a,c,pr,d)
        {
            nume = n;
            socket = s;
            frecventa = f;
            nuclee = nu;
        }

        public Procesor(string n,string p, int a, int c, float pr,DateTime d) : base(p, a,c,pr,d)
        {
            nume = n;
           
        }


        public string Nume
        {
            get { return nume; }
            set
            {
                if (value != null) nume = value;
            }
        }
        public int Socket
        {
            get { return socket; }
            set
            {
                if (value >=0) socket = value;
            }
        }

        public int Frecventa
        {
            get { return frecventa; }
            set
            {
                if (value >= 0) frecventa = value;
            }
        }
        public int Nuclee
        {
            get { return nuclee; }
            set
            {
                if (value >= 0) nuclee = value;
            }
        }



        public override string ToString()
        {
            return "\nProcesorul a fost adaugat."+"\n Denumire model: " + nume + "\n Socket:  " + socket +
                "\n Frecventa(Mhz): " + frecventa + "\n Numar nuclee: " + nuclee + base.ToString();
        }



        public object Clone()
        {
            return this.MemberwiseClone();
        }


        public int CompareTo(object obj)
        {
            Procesor a = (Procesor)obj;
            if (this.nuclee < a.nuclee) return -1;
            else if (this.nuclee > a.nuclee) return 1;
            else return 0;
        }

        public static Procesor operator ++(Procesor p)
        {
            p.nuclee++;
            return p;
        }

        public static bool operator >(Procesor p1, Procesor p2)
        {
            bool status=false;
            if (p1.nuclee > p2.nuclee)
            {
                status=true;
            }
            return status;
        }

        public static bool operator <(Procesor p1, Procesor p2)
        {
            bool status = false;
            if (p1.nuclee < p2.nuclee)
            {
                status = true;
            }
            return status;
        }

        public float CalculeazaValoareProcesor(Procesor p)
        {
            return p.Cantitate * p.Pret;
        }
    }
    




}
