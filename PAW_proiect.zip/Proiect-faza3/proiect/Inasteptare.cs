﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proiect
{
    public partial class Inasteptare : Form
    {
        List<Calculatoare> listaCalc = new List<Calculatoare>();
        public Inasteptare()
        {
            InitializeComponent();
         
        }
   
        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog f = new OpenFileDialog();
            if (f.ShowDialog() == DialogResult.OK)
            {
                listBox1.Items.Clear();

                List<string> lines = new List<string>();
                using (StreamReader r = new StreamReader(f.OpenFile()))
                {
                    string line;
                    while ((line = r.ReadLine()) != null)
                    {
                        listBox1.Items.Add(line);

                    }
                }
            }
        }

        private void listBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (listBox1.Items.Count > 0)
                listBox1.DoDragDrop(listBox1.SelectedItem, DragDropEffects.Copy | DragDropEffects.Move);
        }

        private void listBox2_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.None;
            if (((e.KeyState & 8) == 8) && (e.AllowedEffect & DragDropEffects.Copy) == DragDropEffects.Copy)
                e.Effect = DragDropEffects.Copy;
            else
                if ((e.AllowedEffect & DragDropEffects.Move) == DragDropEffects.Move)
                e.Effect = DragDropEffects.Move;
        }

        private void listBox2_DragDrop(object sender, DragEventArgs e)
        {
            listBox2.Items.Add(e.Data.GetData(DataFormats.Text));
            listBox1.Items.Remove(e.Data.GetData(DataFormats.Text));
        }

        private void listBox3_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.None;
            if (((e.KeyState & 8) == 8) && (e.AllowedEffect & DragDropEffects.Copy) == DragDropEffects.Copy)
                e.Effect = DragDropEffects.Copy;
            else
                if ((e.AllowedEffect & DragDropEffects.Move) == DragDropEffects.Move)
                e.Effect = DragDropEffects.Move;
        }

        private void listBox3_DragDrop(object sender, DragEventArgs e)
        {
            listBox3.Items.Add(e.Data.GetData(DataFormats.Text));
            listBox1.Items.Remove(e.Data.GetData(DataFormats.Text));
        }

        private void listBox4_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.None;
            if (((e.KeyState & 8) == 8) && (e.AllowedEffect & DragDropEffects.Copy) == DragDropEffects.Copy)
                e.Effect = DragDropEffects.Copy;
            else
                if ((e.AllowedEffect & DragDropEffects.Move) == DragDropEffects.Move)
                e.Effect = DragDropEffects.Move;
        }

        private void listBox4_DragDrop(object sender, DragEventArgs e)
        {
            listBox4.Items.Add(e.Data.GetData(DataFormats.Text));
            listBox1.Items.Remove(e.Data.GetData(DataFormats.Text));
        }

        private void listBox5_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.None;
            if (((e.KeyState & 8) == 8) && (e.AllowedEffect & DragDropEffects.Copy) == DragDropEffects.Copy)
                e.Effect = DragDropEffects.Copy;
            else
                if ((e.AllowedEffect & DragDropEffects.Move) == DragDropEffects.Move)
                e.Effect = DragDropEffects.Move;
        }

        private void listBox5_DragDrop(object sender, DragEventArgs e)
        {
            listBox5.Items.Add(e.Data.GetData(DataFormats.Text));
            listBox1.Items.Remove(e.Data.GetData(DataFormats.Text));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string filename = "stoccalculatoare.txt";
            for (int i = 0; i < listBox2.Items.Count; i++)
            {
                File.AppendAllText(filename,"\r\n"+ (string)listBox2.Items[i]);
            }
            MessageBox.Show("Stocul a fost actualizat!");
            listBox2.Items.Clear();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string filename = "stocprocesoare.txt";
            for (int i = 0; i < listBox3.Items.Count; i++)
            {
                File.AppendAllText(filename, "\r\n" + (string)listBox3.Items[i]);
            }
            MessageBox.Show("Stocul a fost actualizat!");
            listBox3.Items.Clear();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string filename = "stocmemorie.txt";
            for (int i = 0; i < listBox4.Items.Count; i++)
            {
                File.AppendAllText(filename, "\r\n" + (string)listBox4.Items[i]);
            }
            MessageBox.Show("Stocul a fost actualizat!");
            listBox4.Items.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string filename = "stocplacivideo.txt";
            for (int i = 0; i < listBox5.Items.Count; i++)
            {
                File.AppendAllText(filename, "\r\n" + (string)listBox5.Items[i]);
            }
            MessageBox.Show("Stocul a fost actualizat!");
            listBox5.Items.Clear();
        }

        private void meniuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Meniu frm1 = new Meniu();
            frm1.ShowDialog();
            this.Close();
        }

        private void calculatoareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            StocCalculatoare frm1 = new StocCalculatoare();
            frm1.ShowDialog();
            this.Close();
        }

        private void procesoareToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            StocProc frm1 = new StocProc();
            frm1.ShowDialog();
            this.Close();
        }

        private void memoriiRAMToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            StocMem frm1 = new StocMem();
            frm1.ShowDialog();
            this.Close();
        }

        private void placiVideoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            StocPlaci frm1 = new StocPlaci();
            frm1.ShowDialog();
            this.Close();
        }
    }
}
