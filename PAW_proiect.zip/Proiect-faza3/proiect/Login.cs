﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proiect
{
    public partial class Login : Form
    {
       
        public Login()
        {
            InitializeComponent();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tbusername_Enter(object sender, EventArgs e)
        {
            tbusername.Text = "";
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            textBox2.Text = "";
            textBox2.PasswordChar = '*';
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string constring = @"Provider = Microsoft.ACE.OLEDB.12.0; Data Source = Administrator.accdb";
            string cmdText = "select Count(*) from Administrator where Username=? and [Password]=?";
            using (OleDbConnection con = new OleDbConnection(constring))
            using (OleDbCommand cmd = new OleDbCommand(cmdText, con))
            {
                con.Open();
                cmd.Parameters.AddWithValue("@p1", tbusername.Text);
                cmd.Parameters.AddWithValue("@p2", textBox2.Text);  
                int result = (int)cmd.ExecuteScalar();
                if (result > 0)
                {
                
                   this.Hide();
                   Meniu m = new Meniu();
                   m.ShowDialog();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Username-ul sau parola incorecte!");
                }
                con.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            tbusername.Text = "";
            textBox2.Text = "";
            textBox2.PasswordChar = '*';
        }
    }
}
