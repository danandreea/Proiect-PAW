﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proiect
{
    public partial class FCalculator : Form
    {
        public List<Calculatoare> lista = new List<Calculatoare>();
        public FCalculator()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           if(checkBox1.Checked==false&&checkBox2.Checked==false)
                errorProvider1.SetError(groupBox1, "Alegeti tipul calculatorului!");
            else
            if (tbModel.Text == "")
                errorProvider1.SetError(tbModel, "Introduceti modelul!");
            else
            if (tbDimensiuni.Text == "")
                errorProvider1.SetError(tbDimensiuni, "Introduceti dimensiunile!");
            else
            if (tbPorturi.Text == "")
                errorProvider1.SetError(tbPorturi, "Introduceti porturile!");
            else
            if (tbCantitate.Text == "")
                errorProvider1.SetError(tbCantitate, "Introduceti cantitatea!");
            else
            if (tbPret.Text == "")
                errorProvider1.SetError(tbPret, "Introduceti pretul!");
            else
            {
                try
                {
                    string tip="";
                    if (checkBox1.Checked)  tip = checkBox1.Text; 
                    else   tip = checkBox2.Text; 
                    string model = tbModel.Text;
                    string[] dimensiunis = tbDimensiuni.Text.Split(',');
                    int[] dimensiuni = new int[dimensiunis.Length];
                    for (int i = 0; i < dimensiunis.Length; i++)
                        dimensiuni[i] = Convert.ToInt32(dimensiunis[i]);
                    string[] porturis = tbPorturi.Text.Split(',');
                    string[] porturi = new string[porturis.Length];
                    for (int i = 0; i < porturis.Length; i++)
                        porturi[i] = porturis[i];
                    int cantitate = Convert.ToInt32(tbCantitate.Text);
                    float pret = Convert.ToSingle(tbPret.Text);
                    DateTime data = this.dateTimePicker1.Value.Date;
                    Calculatoare c = new Calculatoare(tip,model,dimensiuni,porturi,cantitate,pret,data);
                    lista.Add(c);
                    MessageBox.Show("Calculatorul a fost adaugat cu succes!\n"+c.afisare());
                    string filename = "stoccalculatoare.txt";
                    File.AppendAllText(filename, "\r\n" + c.Tip + "-" + c.Model+"-"+ c.Cantitate + "-" + c.Pret+"-"+c.Data);
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

                finally
                {
                    checkBox1.Checked = false;
                    checkBox2.Checked = false;
                    tbModel.Clear();
                    tbDimensiuni.Clear();
                    tbPorturi.Clear();
                    tbCantitate.Clear();
                    tbPret.Clear();
                    dateTimePicker1.Value = DateTime.Now;

                }
            }
        }

        private void checkBox1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked==true)
            {
                checkBox1.Checked = true;
                checkBox2.Checked = false;

            }
        }

        private void checkBox2_Click(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                checkBox2.Checked = true;
                checkBox1.Checked = false;

            }
        }
 

        private void tbCantitate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar >= '0' && e.KeyChar <= '9' || e.KeyChar == (char)8)
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            StocCalculatoare frm = new StocCalculatoare();
            frm.ShowDialog();
            this.Close();
        }

        Thread th;
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(opennewform);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }
        private void opennewform(object obj)
        {
            Application.Run(new Meniu());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            WindowState = WindowState == FormWindowState.Maximized
                       ? FormWindowState.Normal
                       : FormWindowState.Maximized;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

    
    }
    }

